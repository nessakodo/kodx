# Command Line Devlog

This Project empowers you to:

- Clone CLI devlog repo
- Use Git to track your thoughts
- Export and style your markdown log

Follow along with the walkthrough video and fork the starter repo.
