# Secure Shell Basics

This Lab will guide you through:

- Generate SSH key pair
- Connect to remote server
- Use SCP to transfer files

Watch the video and complete the checklist above.
