# Digital Sanctuary Setup

This Lab will guide you through:

- Install a password manager
- Set up encrypted file storage
- Configure privacy browser extensions

Watch the video and complete the checklist above.
